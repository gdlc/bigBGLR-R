#include <bigmemory/MatrixAccessor.hpp>
#include <bigmemory/BigMatrix.h>
#include <Rcpp.h>

#include <Rconfig.h>
#include <Rdefines.h>
#include <Rembedded.h>
#include <R.h>
#include <Rinterface.h>
#include <Rinternals.h>
#include <Rmath.h>
#include <Rversion.h>
#include <R_ext/Lapack.h>

using namespace Rcpp;

double accum_sq(double sum_so_far, double x)
{
    return sum_so_far + x * x;
}

// [[Rcpp::export]]
NumericVector BigColSums2(SEXP XL)
{
    Rcpp::XPtr<BigMatrix> bigMat(XL);
    MatrixAccessor<double> pXL(*bigMat);
    NumericVector colSums2(bigMat->ncol());
    for (size_t i=0; i < bigMat->ncol(); ++i)
    {
        colSums2[i] = std::accumulate(pXL[i], pXL[i]+bigMat->nrow(), 0.0, accum_sq);
    }
    return colSums2;
}

// [[Rcpp::export]]
NumericVector BigColSums(SEXP XL)
{
   Rcpp::XPtr<BigMatrix> bigMat(XL);
   MatrixAccessor<double> pXL(*bigMat);
   NumericVector colSums(bigMat->ncol());
   for(size_t i=0; i< bigMat->ncol();++i)
   {
       colSums[i] = std::accumulate(pXL[i], pXL[i]+bigMat->nrow(), 0.0);
   }
   return colSums; 
}

/*
 * This is a generic function to sample betas in various models, including 
 * Bayesian LASSO, BayesA, Bayesian Ridge Regression, etc.
 
 * For example, in the Bayesian LASSO, we wish to draw samples from the full 
 * conditional distribution of each of the elements in the vector bL. The full conditional 
 * distribution is normal with mean and variance equal to the solution (inverse of the coefficient of the left hand side)
 * of the following equation (See suplementary materials in de los Campos et al., 2009 for details),
   
    (1/varE x_j' x_j + 1/(varE tau_j^2)) bL_j = 1/varE x_j' e
 
    or equivalently, 
    
    mean= (1/varE x_j' e)/ (1/varE x_j' x_j + 1/(varE tau_j^2))
    variance= 1/ (1/varE x_j' x_j + 1/(varE tau_j^2))
    
    xj= the jth column of the incidence matrix
    
 *The notation in the routine is as follows:
 
 n: Number of rows in X
 pL: Number of columns in X
 XL: the matrix X stacked by columns
 XL2: vector with x_j' x_j, j=1,...,p
 bL: vector of regression coefficients
 e: vector with residuals, e=y-yHat, yHat= predicted values
 varBj: vector with variances, 
        For Bayesian LASSO, varBj=tau_j^2 * varE, j=1,...,p
        For Ridge regression, varBj=varB, j=1,...,p, varB is the variance common to all betas.
        For BayesA, varBj=varB_j, j=1,...,p
        For BayesCpi, varBj=varB, j=1,...,p, varB is the variance common to all betas
        
 varE: residual variance
 minAbsBeta: in some cases values of betas near to zero can lead to numerical problems in BL, 
             so, instead of using this tiny number we assingn them minAbsBeta
 
 */


// [[Rcpp::export]]
SEXP sample_beta_big_matrix(SEXP n, SEXP pL, SEXP XL, SEXP xL2, SEXP bL, SEXP e, SEXP varBj, SEXP varE, SEXP minAbsBeta)
{
    double *xj;
    double *pxL2, *pbL, *pe, *pvarBj;
    double b;
    int inc=1;
    double rhs,c,sigma2e, smallBeta;
    int i,j, rows, cols;

    SEXP list;

    Rcpp::XPtr<BigMatrix> bigMat(XL);
    MatrixAccessor<double> pXL(*bigMat);

    GetRNGstate();

    rows=INTEGER_VALUE(n);
    cols=INTEGER_VALUE(pL);
    sigma2e=NUMERIC_VALUE(varE);
    smallBeta=NUMERIC_VALUE(minAbsBeta);
 
    PROTECT(xL2=AS_NUMERIC(xL2));
    pxL2=NUMERIC_POINTER(xL2);

    PROTECT(bL=AS_NUMERIC(bL));
    pbL=NUMERIC_POINTER(bL);

    PROTECT(e=AS_NUMERIC(e));
    pe=NUMERIC_POINTER(e);

    PROTECT(varBj=AS_NUMERIC(varBj));
    pvarBj=NUMERIC_POINTER(varBj);

    //xj=(double *) R_alloc(rows, sizeof(double));

    for(j=0; j<cols;j++)
    {
          //for(i=0;i<rows;i++) xj[i]=pXL[j][i];
          xj=pXL[j];

          b=pbL[j];
          rhs=F77_NAME(ddot)(&rows,xj,&inc,pe,&inc)/sigma2e;
          rhs+=pxL2[j]*b/sigma2e;
          c=pxL2[j]/sigma2e + 1.0/pvarBj[j];
          pbL[j]=rhs/c + sqrt(1.0/c)*norm_rand();

          b-=pbL[j];        

          F77_NAME(daxpy)(&rows, &b,xj,&inc, pe,&inc);

          if(fabs(pbL[j])<smallBeta)
          {
             pbL[j]=smallBeta;
          }
    }

    // Creating a list with 2 vector elements:
    PROTECT(list = Rf_allocVector(VECSXP, 2));
    
    // attaching bL vector to list:
    SET_VECTOR_ELT(list, 0, bL);
    // attaching e vector to list:
    SET_VECTOR_ELT(list, 1, e);

    PutRNGstate();

    UNPROTECT(5);

    return(list);
}
